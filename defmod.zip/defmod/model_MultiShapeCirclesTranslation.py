import torch
import multimodule_usefulfunctions as mm 
import numpy as np
from defmod.shooting import shoot_euler
from defmod.attachement import L2NormAttachement_multi, L2NormAttachement


def armijo(E, gradE, energy, X):
    """ Armijo Stepsize Calculation 
    Args: E: functionvalue at current x
        gradE: gradient at current x
    Returns: alpha: stepsize
    """
    alpha = 1
    p = 0.8
    c1=10**-4
    norm = torch.norm
    while energy(X[0],X[1] - alpha*gradE[0]) > E - c1*alpha*norm(gradE[0]):
        alpha *= p
    return alpha

def gill_murray_wright(E, Enew, gradE,X, Xnew, k, kmax = 1):
    """ Convergence Criteria of Gill, Murray, Wright """
    tau = 10**-8
    eps = 10**-8
    norm = torch.norm
    cond0 = E < Enew
    cond1 = E - Enew < tau*(1 + E)
    cond2 = norm(Xnew[1] - X[1])<np.sqrt(tau)*(1 + (norm(X[1]))**(1/2))
    cond3 = norm(gradE) < tau**(1/3)*(1 + E)
    print(tau**(1/3)*(1 + E))
    cond4 = norm(gradE)<eps
    cond5 = k >= kmax
    print('k, kmax',k, kmax)
    if (cond1 and cond2 and cond3) or cond4 or cond5 or cond0:
        print('Condition 1, 2, 3:',cond1, cond2, cond3)
        print ('Contition 4:', cond4)
        print('Condition 5:', cond5)
        return True
    return False

def gradientdescent( EnergyFunctional , X):
    
    energy = EnergyFunctional.energy_tensor
    energygradient = EnergyFunctional.gradE
    
    [gd, mom] = X
    k = 0
    convergence = False
    
    while convergence == False:
        #print('initial gd, mom______________')
        #print(gd, mom)
        gradE = energygradient(gd, mom)    
        #print('gradient computed_________________')
        
        #print(EnergyFunctional.modules.manifold.gd, EnergyFunctional.modules.manifold.cotan, EnergyFunctional.modules.controls)
        E = energy(gd, mom)
        #print('Energy_computed__________________________')
        #print(EnergyFunctional.modules.manifold.gd, EnergyFunctional.modules.manifold.cotan, EnergyFunctional.modules.controls)

        alpha = 0.1 #armijo(E, gradE, energy, [gd, mom])
        momnew = mom - alpha*gradE
        
        Enew = energy(gd, momnew)
        #print('New_Energy_computed_______________')
        #print(EnergyFunctional.modules.manifold.gd, EnergyFunctional.modules.manifold.cotan, EnergyFunctional.modules.controls)

        
        print(" iter : {}  ,total energy: {}".format(k, Enew))
        convergence = gill_murray_wright(E, Enew, gradE, [gd, mom], [gd, momnew], k)
        mom = momnew.detach().requires_grad_()
        k+=1
        
    print(" iter : {}  ,total energy: {}".format(k, Enew))
    return gd, mom


############################################

class EnergyFunctional():
    def __init__(self, modules, h, Constr, target, dim=2, gamma=1):
        super().__init__()
        self.__modules = modules
        self.h = h
        self.Constr = Constr
        self.target = target
        self.dim = dim
        self.nb_pts = [len(target[0]), len(target[1])]
        self.gamma = gamma
        
    @property
    def modules(self):
        return self.__modules
    
    
        
    def attach(self, target):
        return L2NormAttachement()(self.modules.manifold.gd[0], target[0]) + L2NormAttachement()(self.modules.manifold.gd[1], target[1]) + L2NormAttachement()(self.modules.manifold.gd[2][0], target[0]) + L2NormAttachement()(self.modules.manifold.gd[2][1], target[1])
        
    def cost(self):   
        #cost = 0
        #for i in range(len(self.modules.module_list)):
        #    cost = cost + self.modules.module_list[i].cost()
        return self.modules.cost()
    
    
    def shoot(self):
        
        intermediate_states, intermediate_controls = shoot_euler(self.h, it=10)
        
        return intermediate_states, intermediate_controls
    
    def test(self, gd0, mom0):
        
        gd0_list = self.tensor2list(gd0)
        mom0_list = self.tensor2list(mom0)
        
        self.h.module.manifold.fill_gd(gd0_list)
        self.h.module.manifold.fill_cotan(mom0_list)
        
        return [self.h.module.manifold.gd[0], self.h.module.manifold.gd[1], self.h.module.manifold.gd[2][0], self.h.module.manifold.gd[2][1]]
    
    
    
    def energy_tensor(self, gd0, mom0):
        ''' Energy functional for tensor input
            (to compute the automatic gradient the input is needed as tensor, not as list) '''
        
        gd0_list = self.tensor2list(gd0)
        mom0_list = self.tensor2list(mom0)
        
        self.h.module.manifold.fill_gd(gd0_list)
        self.h.module.manifold.fill_cotan(mom0_list)
        self.h.geodesic_controls()
        print('constr_________________')
        print(self.h.constraints(self.h.module))

        self.shoot()
        print('constr_after_shotting____________')
        print(self.h.constraints(self.h.module))
        
        geodesicControls0 = self.h.module.controls
        gd1 = self.h.module.manifold.gd
                
        cost = self.cost()
        attach = self.attach(self.target)
        #print('cost:', cost, 'attach:', attach, 'gamma:', self.gamma, 'total:', self.gamma*cost + attach)
        
        print(self.h.module.manifold.gd)
        print(self.h.module.manifold.cotan)
        
        return self.gamma*cost + attach
        
    
    def energy(self, gd0, mom0):
        gd_t,_,controls_t = self.shoot(gd0, mom0)
        
        geodesicControls0 = controls_t[0]
        gd1 = gd_t[-1]
        
        z = [mm.computeCenter(gd0[0]), mm.computeCenter(gd0[1]), gd0[2]]
        
        cost = self.cost(z, geodesicControls0)
        attach = self.attach(gd1, self.target)
        
        return self.gamma*cost + attach
    
    def gradE(self, gd0_tensor, mom0_tensor):
        E = self.energy_tensor(gd0_tensor, mom0_tensor)
        E.backward()
        grad = mom0_tensor.grad
        #mom0_tensor.grad.data.zero_()
        return grad
    
    def gradE_autograd(self, gd0_tensor, mom0_tensor):
        grad = torch.autograd.grad(self.energy_tensor(gd0_tensor, mom0_tensor), mom0_tensor)[0]# - grad
        return grad
    
    def tensor2list(self, x):
        x_list = [x[0:self.nb_pts[0]*self.dim], x[self.nb_pts[0]*self.dim:(self.nb_pts[0]+self.nb_pts[1])*self.dim], [x[(self.nb_pts[1]+self.nb_pts[0])*self.dim:(self.nb_pts[1]+2*self.nb_pts[0])*self.dim], x[(self.nb_pts[1]+2*self.nb_pts[0])*self.dim:]]]
        return x_list
    
    def list2tensor(self, x):
        a = [*[a for a in x[:-1]], *[a for a in x[-1]]]
        return torch.cat(a,0).requires_grad_().view(-1).double()
    