from . import usefulfunctions
from . import sampling
from . import shooting
from . import hamiltonian
from . import deformationmodules
from . import models
from . import implicitmodules
from . import manifold
from . import kernels
from . import structuredfield
from . import attachement

#from . import multimodule_structuredfield
from . import multishape
from . import constraints

__version__ = "0.0.2"

